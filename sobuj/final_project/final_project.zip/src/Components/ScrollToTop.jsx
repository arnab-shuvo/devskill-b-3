// import React from 'react'
import React, { useState } from 'react';

// export default function ScrollToTop() {
//   return (
//     <div>
      
//     </div>
//   )
// }

const ScrollToTop = () =>{
    return<>
    
    </>
}
export default ScrollToTop;