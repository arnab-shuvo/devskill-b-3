
const ActionType = {
    getProductList: 'GET-PRODUCT-LIST',
    getProductDetail: 'GET-PRODUCT-DETAIL',
    registration: 'REGISTRATION',
    login:'LOGIN',
    addToCart: 'ADD-TO-CART',
    checkout: 'CHECKOUT',

}
export default ActionType;