export const history = require("history").createBrowserHistory()

