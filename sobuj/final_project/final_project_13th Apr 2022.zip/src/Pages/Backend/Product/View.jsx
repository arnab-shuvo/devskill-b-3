import React, { useState, useEffect } from 'react';

const ProductView =()=>{
    
    return<>

    </>

}
export default ProductView;