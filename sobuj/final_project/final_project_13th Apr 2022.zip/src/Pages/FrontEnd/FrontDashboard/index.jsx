import React from 'react'
import './styles.css';

const FrontDashboard = () => {
  return (
    <div className='wrapper'>
        <h2>This is Dashboard, which is showing after login </h2>
    </div>
  )
}

export default FrontDashboard;
